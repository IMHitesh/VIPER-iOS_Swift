//
//  AppDelegate.swift
//  MVVMBaseCode
//
//  Created by sooryen on 12/06/19.
//  Copyright © 2019 sooryen. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        IQKeyboardManager.shared.enable = true
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        SMNetworkManager.shared.stopNetworkReachabilityObserver()
    }

    func applicationDidEnterBackground(_ application: UIApplication) {

    }

    func applicationWillEnterForeground(_ application: UIApplication) {

    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        SMNetworkManager.shared.startNetworkReachabilityObserver()
    }

    func applicationWillTerminate(_ application: UIApplication) {

    }
}

