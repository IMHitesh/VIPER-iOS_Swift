//
//  NSObject+Extension.swift
//  MVVMBaseCode
//
//  Created by sooryen on 12/06/19.
//  Copyright © 2019 sooryen. All rights reserved.
//


import UIKit
//import SVProgressHUD

//extension NSObject{
    //MARK: - Progress HUD
    func showLoader(){
        DispatchQueue.main.async {
            SVProgressHUD.setDefaultMaskType(.clear)
            SVProgressHUD.setBackgroundColor(UIColor.app_loader_bg)
            SVProgressHUD.setForegroundColor(UIColor.app_theme)
            SVProgressHUD.show()
        }
    }
    
    func hideLoader(){
        DispatchQueue.main.async {
            SVProgressHUD.dismiss()
        }
    }
    
    func showLoader(_ message : String){
        DispatchQueue.main.async {
            SVProgressHUD.setBackgroundColor(UIColor.app_loader_bg)
            SVProgressHUD.setForegroundColor(UIColor.app_theme)
            SVProgressHUD.show(withStatus: message)
        }
    }    
//}



//MARK:Device measurement
extension NSObject {
    
    //MARK:- Shorten Syntex Constants
    var IS_IPAD : Bool{
        return (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiom.pad)
    }
    var SCREEN_WIDTH : CGFloat{
        return (UIScreen.main.bounds.size.width)
    }
    var SCREEN_HEIGHT : CGFloat{
        return (UIScreen.main.bounds.size.height)
    }
    
    //MARK:- Scalling factor for devices
    //Device Layout Reference Guide URL: http://iosres.com/
    var SCALE_W : CGFloat{
        return (SCREEN_WIDTH / 320) //iPhone Default base width = 320
    }
    var SCALE_W_IPAD : CGFloat{
        return (SCREEN_WIDTH / 1024) //iPad Default base width = 1024 (Landscape mode)
    }
    var SCALE_H : CGFloat{
        return (SCREEN_HEIGHT / 568) //iPhone Default base height = 568
    }
    
    //MARK:- Screen Center Constant
    var CENTER_X : CGFloat{
        return (SCREEN_WIDTH / 2)
    }
    var CENTER_Y : CGFloat{
        return (SCREEN_HEIGHT / 2)
    }
}


public protocol ClassNameProtocol {
    static var className: String { get }
    var className: String { get }
}

public extension ClassNameProtocol {
    public static var className: String {
        return String(describing: self)
    }
    
    public var className: String {
        return type(of: self).className
    }
}

extension NSObject: ClassNameProtocol {}
