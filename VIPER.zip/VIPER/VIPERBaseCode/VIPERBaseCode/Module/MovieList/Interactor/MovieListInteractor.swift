//
//  MovieListInteractor.swift
//  VIPERBaseCode
//
//  Created by sooryen on 13/06/19.
//  Copyright © 2019 sooryen. All rights reserved.
//



class MovieListInteractor: MovieListInteractorInputProtocol {
//    var presenter: MovieListPresenter?
    
    
    weak var presenter: MovieListOutputInteractorProtocol?
    
    func getMovies(inMainThread:Bool) {
        if inMainThread {showLoader()}
        API.sharedInstance.apiRequestWithModalClass(modelClass: ModeMoviesList.self, apiName: APIName.MoviesList, requestType: .get, paramValues: nil, headersValues: nil, SuccessBlock: { (response) in

            guard let result = response.results else{
                self.presenter?.movieListDidFetch(movieList: [])
                return
            }

            self.presenter?.movieListDidFetch(movieList: result)
        }) { (error) in
            self.presenter?.didFailedToFetch(message: error.localizedDescription)
            if inMainThread {hideLoader()}
        }
    }}


