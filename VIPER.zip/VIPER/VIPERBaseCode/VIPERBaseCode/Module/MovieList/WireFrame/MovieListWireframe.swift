//
//  MovieListWireframe.swift
//  VIPERBaseCode
//
//  Created by sooryen on 14/06/19.
//  Copyright © 2019 sooryen. All rights reserved.
//

import Foundation


class MovieListWireframe: MovieListWireFrameProtocol {
    class func pushToMovieDetail(movie: Movie, from view: UIViewController) {
        let movieDetailViewController = view.storyboard?.instantiateViewController(withIdentifier: "MovieDetailsVC") as! MovieDetailsVC        
        MovieDetailWireFrame.createMovieDetailModule(controller: movieDetailViewController, movie: movie)
        view.navigationController?.pushViewController(movieDetailViewController, animated: true)
    }
    
    class func createMovieListModule(movieListVC: MovieListVC) {
        let presenter: MovieListPresenterProtocol & MovieListOutputInteractorProtocol = MovieListPresenter()
        movieListVC.presenter = presenter
        movieListVC.presenter?.wireframe = MovieListWireframe()
        movieListVC.presenter?.view = movieListVC
        movieListVC.presenter?.interactor = MovieListInteractor()
        movieListVC.presenter?.interactor?.presenter = presenter as! MovieListPresenter
    }
}
