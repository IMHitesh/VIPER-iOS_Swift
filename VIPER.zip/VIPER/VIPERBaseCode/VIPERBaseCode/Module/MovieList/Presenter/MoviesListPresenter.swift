//
//  MoviesListPresenter.swift
//  VIPERBaseCode
//
//  Created by sooryen on 13/06/19.
//  Copyright © 2019 sooryen. All rights reserved.
//


class MovieListPresenter: MovieListPresenterProtocol {

    var wireframe: MovieListWireFrameProtocol?
    var view: MovieListViewProtocol?
    var interactor: MovieListInteractor? = MovieListInteractor()
    var presenter: MovieListPresenterProtocol?
    
    func viewDidLoad() {
        showLoader()
        interactor?.getMovies(inMainThread: true)
    }
}

extension MovieListPresenter: MovieListOutputInteractorProtocol {
    
    func didFailedToFetch(message: String) {
        view?.showMovies(movies: [])
    }
    
    func movieListDidFetch(movieList: [Movie]) {
        view?.showMovies(movies: movieList)
    }
}

