//
//  MovieListProtocol.swift
//  VIPERBaseCode
//
//  Created by sooryen on 14/06/19.
//  Copyright © 2019 sooryen. All rights reserved.
//


protocol MovieListInteractorInputProtocol: class {
    var presenter: MovieListOutputInteractorProtocol? { get set }
    
    func getMovies(inMainThread:Bool)
}


protocol MovieListViewProtocol: class {
    func showMovies(movies: [Movie])
    func failedToConnectWithAPI(message:String)

}

//MARK:- Presenter protocols ---> View -> Presenter
protocol MovieListPresenterProtocol: class {
    var interactor: MovieListInteractor? {get set}
    var view: MovieListViewProtocol? {get set}
    var wireframe: MovieListWireFrameProtocol? {get set}
    
    func viewDidLoad()
    func movieListDidFetch(movieList: [Movie])
}

//MARK:- Interactor input protocols ----> Presenter -> View -> Interactor
protocol MovieListInputInteractorProtocol: class {
    var presenter: MovieListOutputInteractorProtocol? {get set}
    //Present -> Interactor
    func getMovieList()
}

//MARK:- Interactor output protocols ----> Presenter -> View -> Interactor -> Presenter
protocol MovieListOutputInteractorProtocol: class {
    func movieListDidFetch(movieList: [Movie])
    func didFailedToFetch(message:String)
}


//MARK:- Wireframe protocols ---> Presenter -> Wireframe
protocol MovieListWireFrameProtocol: class {
    static func pushToMovieDetail(movie: Movie,from view: UIViewController)
    static func createMovieListModule(movieListVC: MovieListVC)
}
