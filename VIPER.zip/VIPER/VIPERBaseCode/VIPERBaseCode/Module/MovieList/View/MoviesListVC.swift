//
//  ViewController.swift
//  MVVMBaseCode
//
//  Created by sooryen on 12/06/19.
//  Copyright © 2019 sooryen. All rights reserved.
//

import UIKit
import CRRefresh


class MovieListVC: ParentVC {
    
    @IBOutlet weak var tblMovieList: UITableView!
    var aryMoviesList  = [Movie]()
    
    var presenter:MovieListPresenterProtocol?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        MovieListWireframe.createMovieListModule(movieListVC: self)
        presenter?.viewDidLoad()
        setupData()
    }
    
    fileprivate func setupData() {
        self.title = "Movies List"
        tblMovieList.register(cellType: CellMovieList.self)
        tblMovieList.tableFooterView = UIView()
        setupPagination()
        addPullToRefreshControll()
    }
    
    fileprivate func setupPagination(){
        tblMovieList.cr.addFootRefresh {
            DispatchQueue.main.asyncAfter(deadline:.now()+0.5, execute: {
                self.presenter?.interactor?.getMovies(inMainThread:false)
            })
        }
    }
    
    fileprivate func addPullToRefreshControll(){
        self.tblMovieList.cr.addHeadRefresh {
            DispatchQueue.main.asyncAfter(deadline:.now()+0.5, execute: {
                self.presenter?.interactor?.getMovies(inMainThread:false)
            })
            
        }
    }
    
    fileprivate func refreshViewData() {
        tblMovieList.reloadData()
        hideLoader()
        self.tblMovieList.cr.endLoadingMore()
        self.tblMovieList.cr.endHeaderRefresh()
    }
}


//MARK:API Callback from interactor
extension MovieListVC:MovieListViewProtocol{
    
    func failedToConnectWithAPI(message: String) {
        refreshViewData()
        tblMovieList.setEmptyMessage(message)
    }
    
    func showMovies(movies: [Movie]) {
        aryMoviesList.append(contentsOf: movies)
        refreshViewData()
    }
}
//-------------

//MARK: UITableViewDelegate and UITableViewDatasource
extension MovieListVC:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return aryMoviesList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:"CellMovieList", for: indexPath) as! CellMovieList
        
        cell.objMovies = aryMoviesList[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 110
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        MovieListWireframe.pushToMovieDetail(movie: aryMoviesList[indexPath.row], from: self)
    }
}
