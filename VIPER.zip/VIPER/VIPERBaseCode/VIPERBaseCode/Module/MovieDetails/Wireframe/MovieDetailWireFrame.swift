//
//  MovieDetailWireFrame.swift
//  VIPERBaseCode
//
//  Created by sooryen on 14/06/19.
//  Copyright © 2019 sooryen. All rights reserved.
//

import Foundation


class MovieDetailWireFrame: MovieDetailWireFrameProtocol {
    
    class func createMovieDetailModule(controller: MovieDetailsVC, movie: Movie) {
        let presenter = MovieDetailPresenter()
        presenter.movie = movie
        controller.presenter = presenter
        controller.presenter?.view = controller
        controller.presenter?.wireframe = MovieDetailWireFrame()
    }
}
