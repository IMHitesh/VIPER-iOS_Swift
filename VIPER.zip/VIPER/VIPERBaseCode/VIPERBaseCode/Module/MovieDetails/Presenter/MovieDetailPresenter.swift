//
//  MovieDetailPresenter.swift
//  VIPERBaseCode
//
//  Created by sooryen on 14/06/19.
//  Copyright © 2019 sooryen. All rights reserved.
//

import UIKit

class MovieDetailPresenter: MovieDetailPresenterProtocol {
    
    var view: MovieDetailViewProtocol?
    var wireframe: MovieDetailWireFrameProtocol?
    var movie: Movie?
    
    func viewDidLoad() {
        view?.showMovieDetail(movie:movie!)
    }    
}

