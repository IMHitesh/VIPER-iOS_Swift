//
//  MovieDetailProtocols.swift
//  VIPERBaseCode
//
//  Created by sooryen on 14/06/19.
//  Copyright © 2019 sooryen. All rights reserved.
//

import UIKit

protocol MovieDetailPresenterProtocol: class {
    var wireframe: MovieDetailWireFrameProtocol? {get set}
    var view: MovieDetailViewProtocol? {get set}
    
    //View -> Presenter
    func viewDidLoad()
}

protocol MovieDetailViewProtocol: class {
    //Presenter -> View
    func showMovieDetail(movie:Movie)
}

protocol MovieDetailWireFrameProtocol: class {}
