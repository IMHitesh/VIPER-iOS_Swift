//
//  MovieDetailsVC.swift
//  VIPERBaseCode
//
//  Created by sooryen on 13/06/19.
//  Copyright © 2019 sooryen. All rights reserved.
//

import UIKit

class MovieDetailsVC: UIViewController,MovieDetailViewProtocol {

    @IBOutlet weak var imgMovie: UIImageView!
    var presenter: MovieDetailPresenterProtocol?

    override func viewDidLoad() {
        super.viewDidLoad()
        presenter?.viewDidLoad()
    }
    
    func showMovieDetail(movie: Movie) {
        let strImageURL = domainImage + "w300" + String(movie.poster_path!)
        imgMovie.loadImageFromURL(url: strImageURL, placeholderImage:placeholderImage)
    }
}
