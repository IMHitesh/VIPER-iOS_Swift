//
//  ParentVC.swift
//  MVVMBaseCode
//
//  Created by sooryen on 13/06/19.
//  Copyright © 2019 sooryen. All rights reserved.
//

import UIKit


class ParentVC: UIViewController {
    
    override func viewDidLoad() {
        print("Class Name: \(self)")
        super.viewDidLoad()
        setNeedsStatusBarAppearanceUpdate()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
}

