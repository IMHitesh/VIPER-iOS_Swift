//
//  Font+Helper.swift
//  MVVMBaseCode
//
//  Created by sooryen on 12/06/19.
//  Copyright © 2019 sooryen. All rights reserved.
//


import UIKit

struct fontType {
    
    static let medium_regular = UIFont.init(name:"Montserrat-Regular", size:15)
    static let large_regular = UIFont.init(name:"Montserrat-Regular", size:17)
    
    static let medium = UIFont.init(name:"Montserrat-Medium", size:15)
    static let large_medium = UIFont.init(name:"Montserrat-Medium", size:17)
    
    static let medium_semibold = UIFont.init(name:"Montserrat-SemiBold", size:15)
    static let large_semibold = UIFont.init(name:"Montserrat-SemiBold", size:17)
    
    static let medium_bold = UIFont.init(name:"Montserrat-Bold", size:15)
    static let large_bold = UIFont.init(name:"Montserrat-Bold", size:17)
    
    static let medium_iPhone5 = UIFont.init(name:"Montserrat-Medium", size:12)
    static let medium_bold_iPhone5 = UIFont.init(name:"Montserrat-Bold", size:14)
    
    static let medium_bold_iPhone_5S = UIFont.init(name:"Montserrat-Bold", size:13)
}

